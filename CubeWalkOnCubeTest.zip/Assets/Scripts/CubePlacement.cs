using UnityEngine;

public class CubePlacement : MonoBehaviour
{
    public GameObject cubePrefab; // Drag your cube prefab to this field in the Unity Inspector.
    private GameObject currentCube;
    private Vector3 currentDirection;
    private float moveSpeed = 2.0f; // Adjust the speed as needed.
    private float edgeThreshold = 0.05f; // Adjust this value based on your desired edge proximity.
    private RaycastHit hitInfo; // Store the hit information.

    void Start()
    {
        currentCube = null;
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0)) // Check for a mouse click.
        {
            Ray ray = Camera.main.ScreenPointToRay(Input.mousePosition);

            if (Physics.Raycast(ray, out hitInfo))
            {
                if (currentCube == null)
                {
                    // Determine the perpendicular direction of the hit point.
                    Vector3 perpendicularDirection = hitInfo.normal;

                    // Create a new cube.
                    currentCube = Instantiate(cubePrefab);

                    // Position the new cube on top of the hit cube.
                    Vector3 newPosition = hitInfo.point + perpendicularDirection * (currentCube.transform.localScale.y / 2);
                    currentCube.transform.position = newPosition;

                    // Rotate the new cube to align its up direction with the perpendicular direction.
                    Quaternion rotation = Quaternion.FromToRotation(Vector3.up, perpendicularDirection);
                    currentCube.transform.rotation = rotation;

                    // Set the current direction for movement.
                    currentDirection = perpendicularDirection;
                }
            }
        }

        // Move the current cube using "W," "A," "S," "D" keys.
        if (currentCube != null)
        {
            float horizontalInput = Input.GetAxis("Horizontal");
            float verticalInput = Input.GetAxis("Vertical");

            Vector3 movement = new Vector3(horizontalInput, 0, verticalInput);
            movement = currentCube.transform.TransformDirection(movement);
            currentCube.transform.Translate(movement * moveSpeed * Time.deltaTime);

            // Check if the cube has reached an edge.
            if (IsAtEdgeOfFace(currentCube))
            {
                // Calculate the new direction based on the hit face's normal.
                Vector3 newDirection = Quaternion.AngleAxis(90.0f, hitInfo.normal) * currentDirection;

                // Rotate the cube to align with the new direction.
                Quaternion rotation = Quaternion.FromToRotation(Vector3.up, newDirection);
                currentCube.transform.rotation = rotation;

                // Update the current direction.
                currentDirection = newDirection;
            }
        }
    }

    bool IsAtEdgeOfFace(GameObject cube)
    {
        // Check if the cube's position is close to the edge of the original cube's face.

        // Assuming the original cube's face is centered at (0, 0, 0) and has a size of 1 unit.

        // Get the current cube's position.
        Vector3 cubePosition = cube.transform.position;

        // Calculate the distance from the center of the original cube's face to the cube.
        Vector3 distanceToCenter = cubePosition - Vector3.zero; // Assuming the center is (0, 0, 0).

        // Check if the cube is close to any edge of the face.
        if (Mathf.Abs(distanceToCenter.x) >= 0.5f - edgeThreshold ||
            Mathf.Abs(distanceToCenter.y) >= 0.5f - edgeThreshold ||
            Mathf.Abs(distanceToCenter.z) >= 0.5f - edgeThreshold)
        {
            // The cube is close to the edge.
            return true;
        }

        // If the cube is not close to any edge, return false.
        return false;
    }
}
