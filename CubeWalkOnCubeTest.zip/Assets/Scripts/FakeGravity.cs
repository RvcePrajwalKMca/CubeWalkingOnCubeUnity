﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FakeGravity : MonoBehaviour {

    public float gravity = -10;

    public void Attract(Transform objBody)
    {
        // set planet gravity direction for the object body
        Vector3 gravityDir = (objBody.up).normalized;
        // apply gravity to objects rigidbody
        objBody.GetComponent<Rigidbody>().AddForce(gravityDir * gravity);
    }
}
