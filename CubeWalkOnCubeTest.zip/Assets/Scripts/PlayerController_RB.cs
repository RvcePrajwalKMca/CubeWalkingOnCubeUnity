﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(Rigidbody))]
public class PlayerController_RB : MonoBehaviour {

    // movement
    public float speed = 15.0f;
    private Vector3 moveDirection;
    private Rigidbody playerRigidBody;
    public int currentWorld = 0;

    private float edgeOffset = .5f;
    [SerializeField]
    private GameObject editorCubeHolder;
    [SerializeField]
    private GameObject editorCube;

    //Ray initializations
    public LayerMask modelLayer;

    // Use this for initialization
    void Start() {
        playerRigidBody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update() {
        // update move direction
        moveDirection = new Vector3(Input.GetAxis("Horizontal"), 0, Input.GetAxis("Vertical")).normalized;
        // move editorCube
        moveEditorCubeOperation();
    }

    void FixedUpdate()
    {
        Vector3 clampedPosition = playerRigidBody.position + transform.TransformDirection(moveDirection * speed * Time.fixedDeltaTime);
        // Check if the clamped position is within the bounds of the targetCube.
        if (IsWithinBounds(clampedPosition, editorCubeHolder.transform))
        {
            // Move the cubeToMove to the clamped position.
            playerRigidBody.transform.position = clampedPosition;
        }
    }

    // Check if a position is within the bounds of a cube with a given scale.
    bool IsWithinBounds(Vector3 position, Transform cubeScale)
    {
        float halfX = cubeScale.localScale.x / 2;
        float halfY = cubeScale.localScale.y / 2;
        float halfZ = cubeScale.localScale.z / 2;
        //print("Halves:("+halfX.ToString()+","+halfY.ToString() + "," + halfZ.ToString() + ")");

        return (
                (position.x >= -halfX + edgeOffset && position.x <= halfX - edgeOffset &&
                position.y >= -halfY + edgeOffset && position.y <= halfY - edgeOffset) 
                ||
                (position.y >= -halfY + edgeOffset && position.y <= halfY - edgeOffset &&
                position.z >= -halfZ + edgeOffset && position.z <= halfZ - edgeOffset) 
                ||
                (position.z >= -halfZ + edgeOffset && position.z <= halfZ - edgeOffset &&
                position.x >= -halfX + edgeOffset && position.x <= halfX - edgeOffset)
                );
    }

    void moveEditorCubeOperation() 
    {
        // Define the ray's origin and direction.
        Vector3 rayOrigin = transform.position; // Change this to the desired origin.
        Vector3 rayDirection = -transform.up; // Change this to the desired direction.

        // Create a ray from the origin and direction.
        Ray ray = new Ray(rayOrigin, rayDirection);

        // Declare a RaycastHit variable to store the hit information.
        RaycastHit hit;

        // Draw the ray for debugging purposes.
        Debug.DrawRay(rayOrigin, rayDirection * 100f, Color.red);

        // Perform the raycast.
        if (Physics.Raycast(ray, out hit, Mathf.Infinity, modelLayer))
        {
            // Determine the perpendicular direction of the hit point.
            Vector3 perpendicularDirection = hit.normal;

            // Position the new cube on top of the hit cube.
            Vector3 newPosition = hit.point + perpendicularDirection * (editorCube.transform.localScale.y / 2);
            editorCube.transform.position = newPosition;

            // Rotate the new cube to align its up direction with the perpendicular direction.
            Quaternion rotation = Quaternion.FromToRotation(Vector3.up, perpendicularDirection);
            editorCube.transform.rotation = rotation;
        }
    }
}
