Free Voxel Girl ver1.40

The version of unity in which this asset was created is 5.4.5p5.

These models have 564 tris.

These models are rigged and animated.

11 Mecanim humanoid animations - Idle, Walk, Run, Jump, Jump02, Jump-up, Jump-float, Jump-landing, Damage, Death, Lose
All animations are animated 60fps.

Please feel free to contact us if you have any problems, questions or suggestions.
Contact : shio.ten4010@gmail.com

Website : http://fire-emotion.com/
Twitter : https://twitter.com/shiouten


---Update---

ver1.40 Added 4 animations - Jump02, Jump-up, Jump-float, Jump-landing

ver1.30 Added improved models ( 6 types )

ver1.20 Added 3 animations - Damage, Death, Lose

ver1.10 Added 2 kinds of color variation

ver1.00 First release